{# Drops every schema created for the current target (e.g. DBT_CI_PR_12, DBT_CI_PR_12_RAW, ...).
   Used at the end of CI:  dbt run-operation drop_ci_schemas --target ci
   Refuses to run outside the ci target so it can never drop your dev schemas. #}

{% macro drop_ci_schemas() %}
  {% if target.name != 'ci' %}
    {{ exceptions.raise_compiler_error("drop_ci_schemas only runs with --target ci (current: " ~ target.name ~ ")") }}
  {% endif %}

  {% set q %}
    select schema_name
    from {{ target.database }}.information_schema.schemata
    where schema_name ilike '{{ target.schema }}%'
  {% endset %}

  {% set schemas = run_query(q).columns[0].values() %}
  {% for s in schemas %}
    {% do log("Dropping schema " ~ target.database ~ "." ~ s, info=true) %}
    {% do run_query("drop schema if exists " ~ target.database ~ "." ~ s ~ " cascade") %}
  {% endfor %}
{% endmacro %}
