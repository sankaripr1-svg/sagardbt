-- Fails if any RAW row is unaccounted for (or counted twice).
-- Also checks the RAW count against the seed tables directly.

with seed_count as (
    select count(*) as n from {{ ref('raw_patients') }}
    {% if var('load_batch2', false) %}
    union all
    select count(*) from {{ ref('raw_patients_batch2') }}
    {% endif %}
)

select r.*, s.seed_rows
from {{ ref('audit_row_reconciliation') }} r
cross join (select sum(n) as seed_rows from seed_count) s
where r.difference <> 0
   or r.raw_rows <> s.seed_rows
