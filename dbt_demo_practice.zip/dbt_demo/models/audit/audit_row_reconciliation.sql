-- RAW = STAGING + QUARANTINE + DUPLICATES. difference must be 0.

with c as (
    select
        (select count(*) from {{ ref('stg_patient_validated') }}) as raw_rows,
        (select count(*) from {{ ref('stg_patient') }})           as staging_rows,
        (select count(*) from {{ ref('dq_quarantine') }})         as quarantine_rows,
        (select count(*) from {{ ref('dq_duplicates') }})         as duplicate_rows
)

select
    raw_rows,
    staging_rows,
    quarantine_rows,
    duplicate_rows,
    raw_rows - (staging_rows + quarantine_rows + duplicate_rows) as difference
from c
