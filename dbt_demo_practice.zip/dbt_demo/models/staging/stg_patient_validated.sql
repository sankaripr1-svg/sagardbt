{{ config(materialized='view') }}

-- Every RAW row exactly once, typed, with the FIRST failing DQ rule (or null).
-- One row in = one row out, so counts always reconcile.

with raw as (

    select * from {{ ref('raw_patients') }}
    {% if var('load_batch2', false) %}
    union all
    select * from {{ ref('raw_patients_batch2') }}
    {% endif %}

),

typed as (

    select
        record_id,
        nullif(trim(patient_id), '')            as patient_id,
        trim(first_name)                        as first_name,
        trim(last_name)                         as last_name,
        dob                                     as dob_raw,
        try_cast(dob as date)                   as dob,
        upper(trim(gender))                     as gender,
        lower(trim(email))                      as email,
        phone,
        city,
        state,
        zip,
        try_cast(load_ts as timestamp)          as load_ts
    from raw

)

select
    *,
    case
        when patient_id is null                       then 'MISSING_PATIENT_ID'
        when dob is null                              then 'INVALID_DOB'
        when dob > current_date                       then 'FUTURE_DOB'
        when coalesce(gender, '') not in ('M', 'F', 'U') then 'INVALID_GENDER'
        when email is null or email not like '%_@_%._%'   then 'INVALID_EMAIL'
    end as dq_reason
from typed
