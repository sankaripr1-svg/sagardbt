-- Rows that failed a DQ rule. One row per failed RAW row (not one per rule),
-- so this count can be added directly to the staging count.

select
    record_id,
    'PATIENT'           as entity,
    patient_id,
    dq_reason,
    dob_raw,
    gender,
    email,
    load_ts,
    current_timestamp   as quarantined_at
from {{ ref('stg_patient_validated') }}
where dq_reason is not null
