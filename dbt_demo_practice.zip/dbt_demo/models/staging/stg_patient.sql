-- Clean, current patient records: one row per patient_id (latest load wins).

select
    record_id,
    patient_id,
    first_name,
    last_name,
    dob,
    gender,
    email,
    phone,
    city,
    state,
    zip,
    load_ts
from {{ ref('stg_patient_validated') }}
where dq_reason is null
qualify row_number() over (
    partition by patient_id
    order by load_ts desc, record_id desc
) = 1
