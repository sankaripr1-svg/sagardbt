-- Valid rows that lost deduplication (an older copy of a patient_id).
-- Logged here so they are never "silently" dropped.

select
    record_id,
    patient_id,
    load_ts,
    'SUPERSEDED_BY_NEWER_LOAD' as reason
from {{ ref('stg_patient_validated') }}
where dq_reason is null
qualify row_number() over (
    partition by patient_id
    order by load_ts desc, record_id desc
) > 1
