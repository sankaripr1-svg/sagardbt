{# Scenario A3: build the DQ CASE statement from a list of rules.
   rules = list of {"code": ..., "fails_when": ...}, checked in order; first failure wins. #}

{% macro dq_reason(rules) %}
    case
    {%- for rule in rules %}
        when {{ rule.fails_when }} then '{{ rule.code }}'
    {%- endfor %}
    end
{% endmacro %}

{# Returns just the codes, e.g. for an accepted_values test or documentation. #}
{% macro dq_codes(rules) %}
    {{ return(rules | map(attribute='code') | list) }}
{% endmacro %}
