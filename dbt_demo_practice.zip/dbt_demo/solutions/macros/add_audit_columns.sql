{# Scenario A1: standard audit columns on every model.
   Usage inside a select list:   select col_a, col_b, {{ add_audit_columns() }} from ... #}

{% macro add_audit_columns() %}
    current_timestamp            as dbt_loaded_at,
    '{{ invocation_id }}'        as dbt_invocation_id,
    '{{ this.identifier }}'      as dbt_model_name
{% endmacro %}
