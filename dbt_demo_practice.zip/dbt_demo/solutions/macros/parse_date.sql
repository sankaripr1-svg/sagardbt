{# Scenario A2: one macro, correct SQL per database (adapter.dispatch).
   Accepts YYYY-MM-DD (system A) and DD/MM/YYYY (system B); anything else -> null. #}

{% macro parse_date(column) %}
    {{ return(adapter.dispatch('parse_date')(column)) }}
{% endmacro %}

{% macro snowflake__parse_date(column) %}
    coalesce(
        try_to_date({{ column }}, 'YYYY-MM-DD'),
        try_to_date({{ column }}, 'DD/MM/YYYY')
    )
{% endmacro %}

{% macro duckdb__parse_date(column) %}
    coalesce(
        cast(try_strptime({{ column }}, '%Y-%m-%d') as date),
        cast(try_strptime({{ column }}, '%d/%m/%Y') as date)
    )
{% endmacro %}

{% macro default__parse_date(column) %}
    {{ exceptions.raise_compiler_error("parse_date is not implemented for adapter " ~ adapter.type()) }}
{% endmacro %}
