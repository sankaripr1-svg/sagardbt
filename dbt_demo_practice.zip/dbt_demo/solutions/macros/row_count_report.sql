{# Scenario A5: operational report via run-operation.
   dbt run-operation row_count_report
   dbt run-operation row_count_report --args "{folder: marts}"
   Walks the project graph, so new models appear automatically. #}

{% macro row_count_report(folder=none) %}
  {% if not execute %}{{ return('') }}{% endif %}

  {% set lines = [] %}
  {% for node in graph.nodes.values()
       | selectattr('resource_type', 'in', ['model', 'seed', 'snapshot'])
       | sort(attribute='name') %}

    {% if folder is not none and folder not in node.fqn %}{% continue %}{% endif %}
    {% if node.config.materialized == 'ephemeral' %}{% continue %}{% endif %}

    {% set rel = adapter.get_relation(node.database, node.schema, node.alias or node.name) %}
    {% if rel is none %}
      {% do lines.append(node.name ~ ': NOT BUILT') %}
    {% else %}
      {% set n = run_query('select count(*) from ' ~ rel).columns[0].values()[0] %}
      {% do lines.append(node.name ~ ': ' ~ n) %}
    {% endif %}
  {% endfor %}

  {% do log('--- row counts (' ~ target.name ~ ') ---', info=true) %}
  {% for l in lines %}{% do log(l, info=true) %}{% endfor %}
{% endmacro %}
