{# Scenario B4 helper: read distinct values of a column at compile time,
   so a pivot grows automatically when a new value appears in the data. #}

{% macro get_distinct_values(relation, column, default=[]) %}
  {% if not execute %}{{ return(default) }}{% endif %}
  {% set q %}
    select distinct {{ column }} as v
    from {{ relation }}
    where {{ column }} is not null
    order by 1
  {% endset %}
  {{ return(run_query(q).columns[0].values() | list) }}
{% endmacro %}
