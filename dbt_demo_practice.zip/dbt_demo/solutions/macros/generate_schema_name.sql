{# Scenario A4: environment-aware schema names.
   prod target -> exact custom schema (RAW, STAGING, CORE, MARTS)
   any other   -> <target schema>_<custom>  (e.g. DBT_DEV_STAGING, DBT_CI_PR_12_STAGING)
   dbt calls this macro automatically for every model, seed and snapshot. #}

{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- if custom_schema_name is none -%}
        {{ target.schema }}
    {%- elif target.name == 'prod' -%}
        {{ custom_schema_name | trim | upper }}
    {%- else -%}
        {{ target.schema }}_{{ custom_schema_name | trim }}
    {%- endif -%}
{%- endmacro %}
