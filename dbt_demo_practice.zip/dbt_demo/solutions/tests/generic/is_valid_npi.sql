{# Scenario C2: custom generic test. A test passes when the query returns 0 rows.
   NPI = exactly 10 digits. #}

{% test is_valid_npi(model, column_name) %}

select {{ column_name }}
from {{ model }}
where {{ column_name }} is not null
  and (
        length({{ column_name }}) <> 10
     or try_cast({{ column_name }} as bigint) is null
  )

{% endtest %}
