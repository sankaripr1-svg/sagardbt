-- Scenario B1: valid encounters, latest version of each encounter_id.

select
    encounter_id,
    patient_id,
    provider_id,
    encounter_type,
    admit_date,
    discharge_date,
    diagnosis_code,
    charge_amount,
    status,
    updated_at
from {{ ref('stg_encounters_validated') }}
where dq_reason is null
qualify row_number() over (partition by encounter_id order by updated_at desc) = 1
