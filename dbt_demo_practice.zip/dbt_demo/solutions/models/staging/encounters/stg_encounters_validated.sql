-- Scenarios A2 + A3 + B1: every landed encounter row once, typed, with a DQ verdict.

{% set rules = [
    {"code": "MISSING_ENCOUNTER_ID",   "fails_when": "encounter_id is null"},
    {"code": "MISSING_PATIENT_ID",     "fails_when": "patient_id is null"},
    {"code": "INVALID_ADMIT_DATE",     "fails_when": "admit_date is null"},
    {"code": "DISCHARGE_BEFORE_ADMIT", "fails_when": "discharge_date < admit_date"},
    {"code": "INVALID_ENCOUNTER_TYPE", "fails_when": "coalesce(encounter_type, '') not in ('IP', 'OP', 'ER')"},
    {"code": "NEGATIVE_OR_NULL_CHARGE","fails_when": "charge_amount is null or charge_amount < 0"},
    {"code": "INVALID_DIAGNOSIS_CODE", "fails_when": "diagnosis_code is null or length(diagnosis_code) < 3 or substr(diagnosis_code, 1, 1) not between 'A' and 'Z' or substr(diagnosis_code, 2, 1) not between '0' and '9'"},
] %}

with landed as (

    select * from {{ ref('raw_encounters') }}
    {% if var('load_day', 1) | int >= 2 %}
    union all
    select * from {{ ref('raw_encounters_day2') }}
    {% endif %}

),

typed as (

    select
        nullif(trim(encounter_id), '')                    as encounter_id,
        nullif(trim(patient_id), '')                      as patient_id,
        nullif(trim(provider_id), '')                     as provider_id,
        upper(trim(encounter_type))                       as encounter_type,
        {{ parse_date('admit_date') }}                    as admit_date,
        {{ parse_date('discharge_date') }}                as discharge_date,
        upper(nullif(trim(diagnosis_code), ''))           as diagnosis_code,
        try_cast(charge_amount as decimal(12, 2))         as charge_amount,
        upper(trim(status))                               as status,
        try_cast(updated_at as timestamp)                 as updated_at,
        admit_date                                        as admit_date_raw
    from landed

)

select
    *,
    {{ dq_reason(rules) }} as dq_reason
from typed
