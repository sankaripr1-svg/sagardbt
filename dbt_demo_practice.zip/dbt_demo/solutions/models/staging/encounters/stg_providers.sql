-- Scenario B1: staging = rename, trim, type. No joins, no business logic.

select
    trim(provider_id)                                   as provider_id,
    trim(provider_name)                                 as provider_name,
    trim(specialty)                                     as specialty,
    trim(npi)                                           as npi,
    case when upper(trim(active_flag)) = 'Y'
         then true else false end                       as is_active,
    {{ add_audit_columns() }}
from {{ ref('raw_providers') }}
