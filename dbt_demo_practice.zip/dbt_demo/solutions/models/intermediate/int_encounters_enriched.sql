-- Scenario B2: ephemeral = a reusable CTE. Not created in Snowflake;
-- dbt inlines it into every model that refs it.

select
    e.encounter_id,
    e.patient_id,
    e.provider_id,
    coalesce(p.provider_name, 'Unknown provider')       as provider_name,
    coalesce(p.specialty, 'Unknown')                    as specialty,
    e.encounter_type,
    t.description                                       as encounter_type_desc,
    t.is_inpatient,
    e.admit_date,
    e.discharge_date,
    {{ dbt.datediff('e.admit_date', 'e.discharge_date', 'day') }} as length_of_stay_days,
    e.diagnosis_code,
    coalesce(c.chapter_name, 'Unmapped')                as diagnosis_chapter,
    e.charge_amount,
    e.status,
    e.updated_at
from {{ ref('stg_encounters') }} e
left join {{ ref('stg_providers') }}       p on p.provider_id = e.provider_id
left join {{ ref('ref_encounter_types') }} t on t.encounter_type = e.encounter_type
left join {{ ref('ref_icd10_chapters') }}  c on c.code_letter = substr(e.diagnosis_code, 1, 1)
