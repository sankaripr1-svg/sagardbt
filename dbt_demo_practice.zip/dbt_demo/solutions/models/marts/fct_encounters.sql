-- Scenario B3: incremental MERGE. First run (or --full-refresh) builds everything;
-- later runs only process rows changed since the last load (minus a safety look-back),
-- and MERGE updates existing encounter_ids instead of inserting duplicates.

{{ config(
    materialized='incremental',
    unique_key='encounter_id',
    incremental_strategy='merge',
    on_schema_change='append_new_columns'
) }}

select
    *,
    {{ add_audit_columns() }}
from {{ ref('int_encounters_enriched') }}

{% if is_incremental() %}
where updated_at > (
    select {{ dbt.dateadd('hour', -1 * var('incremental_lookback_hours', 3), 'max(updated_at)') }}
    from {{ this }}
)
{% endif %}
