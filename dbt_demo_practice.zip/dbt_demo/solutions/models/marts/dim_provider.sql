-- Scenario C4: a dimension with an enforced contract (see marts.yml).

select
    provider_id,
    provider_name,
    specialty,
    npi,
    is_active
from {{ ref('stg_providers') }}
