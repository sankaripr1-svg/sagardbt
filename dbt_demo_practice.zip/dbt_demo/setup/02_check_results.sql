-- Run in Snowsight after `dbt build` to inspect each layer.
-- Schema names assume the dev profile schema DBT_DEV.

USE ROLE DBT_DEMO_ROLE;
USE WAREHOUSE DBT_DEMO_WH;
USE DATABASE DEMO_DB;

-- Row counts per layer (the reconciliation you were missing in H360)
SELECT * FROM DBT_DEV_AUDIT.AUDIT_ROW_RECONCILIATION;

-- Why rows were quarantined
SELECT dq_reason, COUNT(*) AS rows_
FROM DBT_DEV_STAGING.DQ_QUARANTINE
GROUP BY 1 ORDER BY 2 DESC;

-- Trace any single raw row through the layers
SELECT 'STAGING'    AS layer, record_id FROM DBT_DEV_STAGING.STG_PATIENT   WHERE record_id = 'R1-000001'
UNION ALL
SELECT 'QUARANTINE',          record_id FROM DBT_DEV_STAGING.DQ_QUARANTINE WHERE record_id = 'R1-000001'
UNION ALL
SELECT 'DUPLICATE',           record_id FROM DBT_DEV_STAGING.DQ_DUPLICATES WHERE record_id = 'R1-000001';

-- After the batch 2 run: patients with more than one history version
SELECT patient_id, city, phone, dbt_valid_from, dbt_valid_to
FROM DBT_DEV_CORE.PATIENT_HIST
WHERE patient_id IN (
    SELECT patient_id FROM DBT_DEV_CORE.PATIENT_HIST GROUP BY 1 HAVING COUNT(*) > 1
)
ORDER BY patient_id, dbt_valid_from;
